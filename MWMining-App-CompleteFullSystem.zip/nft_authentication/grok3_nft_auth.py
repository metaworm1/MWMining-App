import hashlib
from datetime import datetime

class Grok3NFTAuthenticator:
    def __init__(self):
        self.registry = {}

    def generate_fingerprint(self, object_desc):
        timestamp = datetime.now().isoformat()
        raw_data = f"{object_desc}{timestamp}"
        fingerprint = hashlib.sha256(raw_data.encode()).hexdigest()
        return fingerprint

    def mint_nft(self, nft_id, object_desc):
        if nft_id in self.registry:
            return False
        fingerprint = self.generate_fingerprint(object_desc)
        self.registry[nft_id] = {
            "object": object_desc,
            "fingerprint": fingerprint,
            "mint_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "Verified"
        }
        return True

    def authenticate_nft(self, nft_id, object_desc):
        if nft_id not in self.registry:
            return False
        stored = self.registry[nft_id]["fingerprint"]
        new = self.generate_fingerprint(object_desc)
        return stored == new
