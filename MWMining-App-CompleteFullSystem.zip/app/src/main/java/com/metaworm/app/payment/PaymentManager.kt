package com.metaworm.app.payment

class PaymentManager {
    fun initiatePayment(amount: Double, userId: String): Boolean {
        return true
    }
}
